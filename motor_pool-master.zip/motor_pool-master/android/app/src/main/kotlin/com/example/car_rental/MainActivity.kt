package com.example.car_rental

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
