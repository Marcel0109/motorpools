class Routes {
  static const homescreen = '/';
}
