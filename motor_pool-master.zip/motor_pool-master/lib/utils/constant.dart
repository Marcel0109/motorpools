enum UserType { user, admin }

enum AboutusUsage { loginPage, homePage }
